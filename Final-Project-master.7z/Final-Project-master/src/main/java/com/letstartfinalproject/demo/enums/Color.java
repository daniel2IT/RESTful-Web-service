package com.letstartfinalproject.demo.enums;

public enum Color {
    BALTAS,
    JUODAS,
    RAUDONAS,
    MELYNA,
    VIOLETINE,
    ZALIA,
    GELTONA,
    ZYDRA,
    RUDA,
    RAUSVA
}
